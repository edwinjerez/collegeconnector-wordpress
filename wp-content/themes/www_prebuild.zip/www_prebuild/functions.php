<?php 
// pretty globals for easy links
define( 'TEMPPATH', get_bloginfo('stylesheet_directory'));
define( 'STYLES', TEMPPATH);
define( 'SCRIPTS', TEMPPATH. "/scripts");
define( 'IMAGES', TEMPPATH. "/images");



// add theme scripts
function theme_scripts() {
	// dereg jQuery
	wp_deregister_script('jquery');
	
    wp_register_script( 'jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/1.12.3/jquery.min.js', NULL, NULL, true); // jQuery
	wp_register_script('scripts',SCRIPTS.'/scripts.js',NULL,NULL,true);
	wp_register_script('foundation-6',SCRIPTS.'/foundation.min.js', NULL, NULL, true);
	wp_register_style('foundation-6-css',STYLES.'/foundation.min.css');
	wp_register_style('home-styles',STYLES.'/home-styles.css');
	wp_register_style('interior-styles',STYLES.'/interior-styles.css');
	
	
    wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'foundation-6' );
	wp_enqueue_style( 'foundation-6-css' );
	
	if(is_front_page()) {
		wp_enqueue_style('home-styles');
	} else {
		wp_enqueue_style('interior-styles');
	}
	wp_enqueue_script('scripts');
}
add_action('wp_enqueue_scripts','theme_scripts');


// add blog sidebar
function theme_register_sidebars() {
	register_sidebar( array(
		'name'=>'Blog Sidebar',
		'id'=>'blog',
		'before_widget'=>'<div id="%1$s" class="widget %2$s">',
		'after_widget'=>'</div>',
		'before_title'=>'<h4>',
		'after_title'=>'</h4>'
	));
	register_sidebar( array(
		'name'=>'Contact Us Sidebar',
		'id'=>'contact-sidebar',
		'before_widget'=>'<div id="%1$s" class="widget %2$s">',
		'after_widget'=>'</div>',
		'before_title'=>'<h4>',
		'after_title'=>'</h4>'
	));
}
add_action('widgets_init','theme_register_sidebars');


// add a custom post type
function register_post_types() {
    register_post_type( 'location', array(
        'labels' => array(
			'name'                  => 'Locations',
			'singular_name'         => 'Location',
			'menu_name'             => 'Locations',
			'name_admin_bar'        => 'Location',
			'add_new'               => 'Add New',
			'add_new_item'          => 'Add New Location',
			'new_item'              => 'New Location',
			'edit_item'             => 'Edit Location',
			'view_item'             => 'View Location',
			'all_items'             => 'All Locations',
			'search_items'          => 'Search Locations',
			'parent_item_colon'     => 'Parent Locations:',
			'not_found'             => 'No location information found.',
			'not_found_in_trash'    => 'No location information found in trash.',
			'featured_image'        => 'Location Image',
			'set_featured_image'    => 'Set location image',
			'remove_featured_image' => 'Remove location image',
			'use_featured_image'    => 'Use as location image',
			'archives'              => 'Location Archives',
			'insert_into_item'      => 'Insert into location information',
			'uploaded_to_this_item' => 'Uploaded to this location\'s information',
			'filter_items_list'     => 'Filter locations list',
			'items_list_navigation' => 'Locations list navigation',
			'items_list'            => 'Locations list',
		),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'location' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail' ),
    ));
	
	
}
 
add_action( 'init', 'register_post_types' );



// add login image
function theme_login_logo() { ?>
	<style type="text/css">
		.login h1 a {
			background-image: url("<?=IMAGES;?>/siteLogo-cs.png");
			padding-bottom: 100px;
			height: auto;
			width: auto;
			background-size: 250px auto;
		}
	</style>
<? }
add_action('login_enqueue_scripts','theme_login_logo');


// add logo link image
function theme_login_link() {
	return home_url();
}
add_filter('login_headerurl','theme_login_link');




// add media size for homepage rotator
add_action('after_setup_theme','theme_rotator_media_size');
function theme_rotator_media_size() {
	add_image_size('rotator-slide',1600,404,true);
}
add_filter('image_size_names_choose','theme_custom_sizes');
function theme_custom_sizes($sizes) {
	return array_merge($sizes, array(
		'rotator-slide' => 'Homepage Rotator Slide',
	));
}



// Callback function to filter the MCE settings
add_filter( 'tiny_mce_before_init', 'theme_before_init_insert_formats' );  
function theme_before_init_insert_formats( $init_array ) {  
	// Define the style_formats array
	$style_formats = array(  
		// Each array child is a format with it's own settings
		array(
			'title' => 'Medium Header',
			'block' => 'h2',
		),
		array(  
			'title' => 'Small Header',  
			'block' => 'h3',
		),
		array(
			'title' => 'Content Text',
			'block' => 'p',
		),
		array(
			'title' => 'Button',
			'selector' => 'a',
			'classes' => 'content-button',
		),
	);  
	// Insert the array, JSON ENCODED, into 'style_formats'
	$init_array['style_formats'] = json_encode( $style_formats );  
	
	return $init_array;  
  
} 
// add editor styles
add_action( 'init', 'theme_add_editor_styles' );
function theme_add_editor_styles() {
    add_editor_style( 'tinymce-styles.css' );
}



?>