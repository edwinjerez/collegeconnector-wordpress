<?php
	// Template Name: Contact Us
	
	// pull from contact.html
?>