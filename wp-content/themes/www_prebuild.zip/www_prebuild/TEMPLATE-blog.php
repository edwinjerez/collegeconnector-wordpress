<?php
	// Template Name: Blog
	
	// pull from blog.html
?>