<?php
	// pull this from interior.html
?>