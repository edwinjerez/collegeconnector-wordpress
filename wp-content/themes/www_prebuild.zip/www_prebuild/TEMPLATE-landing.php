<?php
	// Template Name: Landing Page
	
	// pull from landing.html
?>