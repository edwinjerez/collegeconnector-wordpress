<?php
	// Contact Us sidebar
	
	dynamic_sidebar('contact');
?>