<?php
	// general sidebar
	
	dynamic_sidebar();
?>