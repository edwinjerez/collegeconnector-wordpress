<?php
	// blog sidebar
	
	dynamic_sidebar('blog');
?>