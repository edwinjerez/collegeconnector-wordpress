<?php
	// pull from single.html
?>